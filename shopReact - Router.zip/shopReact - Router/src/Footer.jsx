export default function Footer() {
    return (<footer>
        <p>©{new Date().getFullYear()} Tienda</p>
    </footer>)
};